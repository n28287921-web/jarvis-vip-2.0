# JARVIS VIP 2.0 — Android source

Native Kotlin + Jetpack Compose starter for package `com.nasim.jarvisvip`.

## What's updated in this source
- Android app version `2.0` / versionCode `2`.
- Google Gemini backend proxy (`backend/server.js`); no OpenAI integration remains.
- Hindi/English speech input using the Android speech-recognition provider.
- Android Text-to-Speech output; the actual voice/gender depends on voices installed and selected by the device.
- Gemini chat screen (requires the backend URL to be configured).
- Quick actions: launch camera, YouTube, web search, open the phone dialer, and prepare a WhatsApp/share draft. Calls/messages are not sent silently.
- Experimental foreground “Hey JARVIS” wake-word prototype retained from the starter.
- User-enabled Accessibility Service for explicit swipe-up / swipe-down controls. It does not retrieve screen text or silently tap controls.
- Hindi/English voice commands for camera launch, YouTube launch, and explicit scroll up/down after Accessibility is enabled.
- Local AI memory save/delete. The saved note is sent to the Gemini backend as context when the user chats.
- Local task list with add/remove and “Run” (Run places the task into the Gemini chat composer for the user to review/send; it does not execute arbitrary actions or run on a schedule).
- Custom prompt-tool list with add/remove and “Use” (sends the selected tool instruction to Gemini as a prompt; it does not install executable plugins or grant phone permissions).
- Local activity history with clear-history control and a privacy note.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Important limitations and safety
The wake-word implementation uses Android `SpeechRecognizer`; it is not a dedicated always-on offline wake-word engine and may stop due to Android/OEM background and battery restrictions. The task manager is a manual task list, not a background scheduler. Custom tools are prompt shortcuts, not arbitrary executable plugins. Accessibility scrolling is a user-triggered swipe only; it does not read screen contents or automate arbitrary third-party UI. YouTube is opened externally, not controlled inside the app. Android does not permit unrestricted silent control of other apps. WhatsApp remains a draft/share flow and calls open the dialer for user confirmation.

## Configure Gemini backend
1. Deploy the `backend/` folder to a trusted Node.js host that provides HTTPS and Node.js 18+ (native `fetch`).
2. Set the server environment secret `GEMINI_API_KEY` to your Google AI Studio Gemini API key. Optionally set `GEMINI_MODEL` (default `gemini-2.5-flash`) and `PORT`.
3. Do not put the Gemini key in the APK, Kotlin source, Git repository, or a public client app.
4. Edit `BACKEND_URL` near the top of `app/src/main/java/com/nasim/jarvisvip/MainActivity.kt` to the deployed HTTPS `/chat` endpoint. Replace the placeholder `https://YOUR-HTTPS-BACKEND-DOMAIN/chat`.
5. Rebuild the APK after setting the URL. The saved memory note is sent to Gemini as chat context; do not save passwords, API keys, financial details, or other secrets in memory.

Backend health check: `https://YOUR-HOST/health`.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the **contents** of this `JARVIS-VIP` folder to its root.
2. Open **Actions** → **Build JARVIS VIP APK** → **Run workflow**.
3. Wait for the workflow to finish successfully.
4. Open the successful run → **Artifacts** → download `JARVIS-VIP-debug-APK`.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Build locally
Use JDK 17, Android SDK 35, and Gradle 8.9 or compatible. From this folder run:

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions and safety
Microphone permission is needed for speech input/wake listening. Wake listening uses a foreground service and persistent notification. Accessibility must be enabled manually in Android Settings; it is used only for the app's explicit swipe buttons/voice scroll commands and does not read window content. The dialer opens for user review; WhatsApp opens a draft/share sheet. The app does not request contacts, SMS, or call-log permissions.
