package com.nasim.jarvisvip

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** User-enabled accessibility helper. It performs only an explicit swipe requested in the app. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { active = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* No screen content is collected. */ }
    override fun onInterrupt() {}
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    fun swipe(forward: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val x = metrics.widthPixels * 0.5f
        val startY = if (forward) metrics.heightPixels * 0.78f else metrics.heightPixels * 0.25f
        val endY = if (forward) metrics.heightPixels * 0.25f else metrics.heightPixels * 0.78f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 420))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    companion object {
        @Volatile private var active: JarvisAccessibilityService? = null
        fun scroll(forward: Boolean): Boolean = active?.swipe(forward) ?: false
        fun isEnabled(): Boolean = active != null
    }
}
