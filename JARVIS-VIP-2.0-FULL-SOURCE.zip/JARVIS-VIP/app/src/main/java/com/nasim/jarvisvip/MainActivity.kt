package com.nasim.jarvisvip

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private const val BACKEND_URL = "https://YOUR-HTTPS-BACKEND-DOMAIN/chat"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val speechPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speechPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        setContent {
            JarvisVipScreen(
                onSpeak = { speak(it) },
                onListen = { startSpeechInput() },
                onOpenCamera = { launchSafely(Intent("android.media.action.IMAGE_CAPTURE")) },
                onOpenYouTube = { launchSafely(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))) },
                onWebSearch = { q -> launchSafely(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q)) },
                onDial = { number -> launchSafely(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) },
                onWhatsApp = { message ->
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
                        setPackage("com.whatsapp")
                    }
                    if (i.resolveActivity(packageManager) != null) launchSafely(i)
                    else launchSafely(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message), "Share message"))
                },
                onChat = { messages, callback -> askGemini(messages, callback) },
                onWakeStart = {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
                    else speechPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onWakeStop = { stopService(Intent(this, WakeWordService::class.java)) }
            )
        }
    }

    private fun launchSafely(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun startSpeechInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speechPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN,en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak Hindi or English")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { speechLauncher.launch(intent) } catch (_: Exception) { }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) setRecognizedText(spoken)
    }

    private var recognizedCallback: ((String) -> Unit)? = null
    private fun setRecognizedText(text: String) { recognizedCallback?.invoke(text) }

    private fun askGemini(messages: List<Pair<String, String>>, callback: (Result<String>) -> Unit) {
        Thread {
            try {
                if (BACKEND_URL.contains("YOUR-HTTPS-BACKEND-DOMAIN")) throw IllegalStateException("Set BACKEND_URL in MainActivity.kt after deploying the Gemini backend.")
                val conn = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val arr = JSONArray()
                messages.takeLast(30).forEach { (role, content) -> arr.put(JSONObject().put("role", role).put("content", content)) }
                val memory = getSharedPreferences("jarvis_private", MODE_PRIVATE).getString("memory", "") ?: ""
                conn.outputStream.use { it.write(JSONObject().put("messages", arr).put("memory", memory).toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw IllegalStateException(JSONObject(body).optString("error", "Gemini backend error"))
                val reply = JSONObject(body).optString("reply")
                if (reply.isBlank()) throw IllegalStateException("Gemini returned an empty reply")
                runOnUiThread { callback(Result.success(reply)) }
                conn.disconnect()
            } catch (e: Exception) { runOnUiThread { callback(Result.failure(e)) } }
        }.start()
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        val locale = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }

    @Composable
    private fun JarvisVipScreen(
        onSpeak: (String) -> Unit,
        onListen: () -> Unit,
        onOpenCamera: () -> Unit,
        onOpenYouTube: () -> Unit,
        onWebSearch: (String) -> Unit,
        onDial: (String) -> Unit,
        onWhatsApp: (String) -> Unit,
        onChat: (List<Pair<String, String>>, (Result<String>) -> Unit) -> Unit,
        onWakeStart: () -> Unit,
        onWakeStop: () -> Unit
    ) {
        var input by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var draft by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf("") }
        val history = remember { mutableStateListOf<Pair<String, String>>() }
        val prefs = remember { getSharedPreferences("jarvis_private", MODE_PRIVATE) }
        var memoryDraft by remember { mutableStateOf("") }
        var savedMemory by remember { mutableStateOf(prefs.getString("memory", "") ?: "") }
        var taskDraft by remember { mutableStateOf("") }
        var toolDraft by remember { mutableStateOf("") }
        val tasks = remember { mutableStateListOf<String>().apply { runCatching { JSONArray(prefs.getString("tasks", "[]")).let { a -> for (i in 0 until a.length()) add(a.getString(i)) } } } }
        val tools = remember { mutableStateListOf<String>().apply { runCatching { JSONArray(prefs.getString("tools", "[]")).let { a -> for (i in 0 until a.length()) add(a.getString(i)) } } } }
        val activityLogs = remember { mutableStateListOf<String>().apply { runCatching { JSONArray(prefs.getString("activity", "[]")).let { a -> for (i in 0 until a.length()) add(a.getString(i)) } } } }
        var showMemoryDialog by remember { mutableStateOf(false) }
        var showTasksDialog by remember { mutableStateOf(false) }
        var showToolsDialog by remember { mutableStateOf(false) }
        var showHistoryDialog by remember { mutableStateOf(false) }
        val logActivity: (String) -> Unit = { action ->
            activityLogs.add(0, "${java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(java.util.Date())} • $action")
            while (activityLogs.size > 100) activityLogs.removeAt(activityLogs.lastIndex)
            prefs.edit().putString("activity", JSONArray(activityLogs).toString()).apply()
        }
        val persistItems: (String, List<String>) -> Unit = { key, values -> prefs.edit().putString(key, JSONArray(values).toString()).apply() }
        // Speech input callback is registered against this screen instance.
        DisposableEffect(Unit) {
            recognizedCallback = { spoken ->
                val command = spoken.lowercase(Locale.ROOT)
                when {
                    command.contains("scroll down") || command.contains("neeche scroll") || command.contains("नीचे स्क्रॉल") -> {
                        input = ""; val ok = JarvisAccessibilityService.scroll(true)
                        logActivity(if (ok) "Voice command: scroll down" else "Voice scroll unavailable")
                        if (!ok) error = "Enable JARVIS Accessibility settings before scrolling."
                    }
                    command.contains("scroll up") || command.contains("upar scroll") || command.contains("ऊपर स्क्रॉल") -> {
                        input = ""; val ok = JarvisAccessibilityService.scroll(false)
                        logActivity(if (ok) "Voice command: scroll up" else "Voice scroll unavailable")
                        if (!ok) error = "Enable JARVIS Accessibility settings before scrolling."
                    }
                    command.contains("open camera") || command.contains("camera kholo") || command.contains("कैमरा खोलो") -> { input = ""; onOpenCamera(); logActivity("Voice command: open camera") }
                    command.contains("open youtube") || command.contains("youtube kholo") || command.contains("यूट्यूब खोलो") -> { input = ""; onOpenYouTube(); logActivity("Voice command: open YouTube") }
                    else -> input = spoken
                }
            }
            onDispose { recognizedCallback = null }
        }
        val navy = Color(0xFF061426)
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF39BFFF), background = navy, surface = Color(0xFF10243C))) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(navy, Color(0xFF0B2850), navy))).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("JARVIS VIP 2.0", color = Color(0xFF7DD8FF), fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("GOOGLE GEMINI AI  •  HINDI + ENGLISH", color = Color(0xFF9CB8D5), fontSize = 11.sp, letterSpacing = 1.5.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onWakeStart, modifier = Modifier.weight(1f)) { Text("Start Hey JARVIS") }
                    OutlinedButton(onClick = onWakeStop, modifier = Modifier.weight(1f)) { Text("Stop Wake Word") }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).background(Color(0x2239BFFF), CircleShape), contentAlignment = Alignment.Center) {
                        Text("J", color = Color(0xFF7DD8FF), fontSize = 30.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column { Text("Your personal assistant", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Chat with Gemini or use phone shortcuts", color = Color.LightGray, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth().height(260.dp), colors = CardDefaults.cardColors(containerColor = Color(0xCC10243C)), shape = RoundedCornerShape(18.dp)) {
                    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (history.isEmpty()) item { Text("Namaste! Main JARVIS hoon. Hindi ya English mein poochhiye.", color = Color.White) }
                        items(history) { (role, text) ->
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (role == "user") Alignment.End else Alignment.Start) {
                                Text(if (role == "user") "YOU" else "JARVIS", color = Color(0xFF7DD8FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Surface(color = if (role == "user") Color(0xFF164B72) else Color(0xFF1B3048), shape = RoundedCornerShape(12.dp)) {
                                    Text(text, Modifier.padding(10.dp), color = Color.White, fontSize = 14.sp)
                                }
                            }
                        }
                        if (busy) item { Text("JARVIS is thinking…", color = Color(0xFF7DD8FF)) }
                    }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B9B), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask JARVIS…") }, singleLine = false, maxLines = 3, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
                    Spacer(Modifier.width(6.dp))
                    Column { Button(onClick = onListen, contentPadding = PaddingValues(10.dp)) { Text("🎙") }; Button(onClick = {
                        val q = input.trim(); if (q.isNotEmpty() && !busy) {
                            history.add("user" to q); logActivity("Sent chat prompt to Gemini"); input = ""; error = ""; busy = true
                            val request = history.toList()
                            onChat(request) { result -> busy = false; result.onSuccess { history.add("assistant" to it); onSpeak(it) }.onFailure { error = it.message ?: "Request failed" } }
                        }
                    }, contentPadding = PaddingValues(10.dp), enabled = !busy) { Text("➤") } }
                }
                Spacer(Modifier.height(8.dp))
                Text("QUICK ACTIONS", color = Color(0xFF7DD8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = onOpenCamera, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Camera", fontSize = 11.sp) }
                    OutlinedButton(onClick = onOpenYouTube, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("YouTube", fontSize = 11.sp) }
                    OutlinedButton(onClick = { onWebSearch(input.ifBlank { "latest news" }) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Search", fontSize = 11.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, modifier = Modifier.weight(1f), placeholder = { Text("Phone number") }, singleLine = true)
                    Button(onClick = { if (phone.isNotBlank()) onDial(phone) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Dial") }
                }
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("WhatsApp message draft") }, maxLines = 2)
                OutlinedButton(onClick = { if (draft.isNotBlank()) onWhatsApp(draft) }, modifier = Modifier.fillMaxWidth()) { Text("Open WhatsApp / Share draft") }
                Spacer(Modifier.height(8.dp))
                Text("ADVANCED CONTROLS", color = Color(0xFF7DD8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { showMemoryDialog = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("AI Memory", fontSize = 10.sp) }
                    OutlinedButton(onClick = { showTasksDialog = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Tasks (${tasks.size})", fontSize = 10.sp) }
                    OutlinedButton(onClick = { showToolsDialog = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("My Tools (${tools.size})", fontSize = 10.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { launchSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Enable Accessibility", fontSize = 10.sp) }
                    OutlinedButton(onClick = { val ok = JarvisAccessibilityService.scroll(true); logActivity(if (ok) "Scroll down gesture" else "Scroll unavailable: enable JARVIS Accessibility"); if (!ok) error = "Enable JARVIS in Android Accessibility settings first." }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Scroll ↓", fontSize = 10.sp) }
                    OutlinedButton(onClick = { val ok = JarvisAccessibilityService.scroll(false); logActivity(if (ok) "Scroll up gesture" else "Scroll unavailable"); if (!ok) error = "Enable JARVIS in Android Accessibility settings first." }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Scroll ↑", fontSize = 10.sp) }
                }
                OutlinedButton(onClick = { showHistoryDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Activity History & Privacy (${activityLogs.size})") }
                Text("Calls open the dialer; WhatsApp opens a draft for your review. Scrolling works only after you enable the accessibility service. Memory, tasks, tools and history are stored locally on this device. Female voice availability depends on voices installed on your phone.", color = Color(0xFF9CB8D5), fontSize = 10.sp)

                if (showMemoryDialog) AlertDialog(
                    onDismissRequest = { showMemoryDialog = false },
                    title = { Text("JARVIS AI Memory") },
                    text = { Column {
                        Text("Save a note locally. When you chat with Gemini, this note is included as context. You can delete it here any time.", fontSize = 12.sp)
                        OutlinedTextField(value = memoryDraft, onValueChange = { memoryDraft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Memory note") }, minLines = 2)
                        if (savedMemory.isNotBlank()) Text("Saved: $savedMemory", fontSize = 11.sp)
                    } },
                    confirmButton = { TextButton(onClick = { savedMemory = memoryDraft.trim(); prefs.edit().putString("memory", savedMemory).apply(); logActivity("Saved AI memory"); memoryDraft = ""; showMemoryDialog = false }) { Text("Save") } },
                    dismissButton = { Row { TextButton(onClick = { savedMemory = ""; memoryDraft = ""; prefs.edit().remove("memory").apply(); logActivity("Deleted AI memory") }) { Text("Delete") }; TextButton(onClick = { showMemoryDialog = false }) { Text("Close") } } }
                )
                if (showTasksDialog) AlertDialog(
                    onDismissRequest = { showTasksDialog = false },
                    title = { Text("Automation Task Manager") },
                    text = { Column {
                        Text("Create a personal task list. Run marks a task as selected; it does not silently control other apps.", fontSize = 11.sp)
                        OutlinedTextField(value = taskDraft, onValueChange = { taskDraft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("New task") }, singleLine = true)
                        TextButton(onClick = { if (taskDraft.isNotBlank()) { tasks.add(taskDraft.trim()); persistItems("tasks", tasks); logActivity("Added task: ${taskDraft.trim()}"); taskDraft = "" } }) { Text("+ Add task") }
                        tasks.forEachIndexed { index, task -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(task, Modifier.weight(1f), fontSize = 12.sp)
                            TextButton(onClick = { input = "Help me complete this task: $task"; logActivity("Selected task: $task"); showTasksDialog = false }) { Text("Run") }
                            TextButton(onClick = { tasks.removeAt(index); persistItems("tasks", tasks); logActivity("Removed task: $task") }) { Text("×") }
                        } }
                    } },
                    confirmButton = { TextButton(onClick = { showTasksDialog = false }) { Text("Done") } }
                )
                if (showToolsDialog) AlertDialog(
                    onDismissRequest = { showToolsDialog = false },
                    title = { Text("Custom AI Tools") },
                    text = { Column {
                        Text("Add a named prompt shortcut. Selecting Use sends its description to Gemini; it does not grant new Android permissions.", fontSize = 11.sp)
                        OutlinedTextField(value = toolDraft, onValueChange = { toolDraft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Tool name / instruction") }, minLines = 2)
                        TextButton(onClick = { if (toolDraft.isNotBlank()) { tools.add(toolDraft.trim()); persistItems("tools", tools); logActivity("Added custom tool: ${toolDraft.trim()}"); toolDraft = "" } }) { Text("+ Add tool") }
                        tools.forEachIndexed { index, tool -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tool, Modifier.weight(1f), fontSize = 12.sp)
                            TextButton(onClick = { input = "Use this custom tool/instruction: $tool"; logActivity("Used custom tool: $tool"); showToolsDialog = false }) { Text("Use") }
                            TextButton(onClick = { tools.removeAt(index); persistItems("tools", tools); logActivity("Removed custom tool: $tool") }) { Text("×") }
                        } }
                    } },
                    confirmButton = { TextButton(onClick = { showToolsDialog = false }) { Text("Done") } }
                )
                if (showHistoryDialog) AlertDialog(
                    onDismissRequest = { showHistoryDialog = false },
                    title = { Text("Activity & Privacy") },
                    text = { Column {
                        Text("Activity entries are stored locally. Clearing them does not erase Gemini provider logs or Android system logs.", fontSize = 11.sp)
                        LazyColumn(Modifier.heightIn(max = 300.dp)) { items(activityLogs) { entry -> Text(entry, color = Color(0xFFBBD8EE), fontSize = 11.sp, modifier = Modifier.padding(vertical = 3.dp)) } }
                    } },
                    confirmButton = { TextButton(onClick = { activityLogs.clear(); prefs.edit().remove("activity").apply(); showHistoryDialog = false }) { Text("Clear history") } },
                    dismissButton = { TextButton(onClick = { showHistoryDialog = false }) { Text("Close") } }
                )
            }
        }
    }
}
