package com.nasim.jarvisvip

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val channelId = "jarvis_wake_listener"

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS VIP is listening")
            .setContentText("Say: Hey JARVIS")
            .setOngoing(true).build()
        startForeground(71, notification)
        beginListening()
        return START_STICKY
    }
    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Log.e("JARVIS", "Speech recognition unavailable"); stopSelf(); return }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) { listening = false; restart() }
                override fun onResults(results: Bundle?) { handle(results); restart() }
                override fun onPartialResults(partialResults: Bundle?) { handle(partialResults) }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            recognizer?.startListening(i)
        } catch (e: Exception) { Log.e("JARVIS", "Could not start speech recognizer", e); restart() }
    }
    private fun handle(bundle: Bundle?) {
        val phrases = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (phrases.any { it.lowercase(Locale.ROOT).contains("hey jarvis") || it.lowercase(Locale.ROOT).contains("हे जार्विस") }) {
            val launch = packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launch?.putExtra("WAKE_TRIGGERED", true)
            if (launch != null) startActivity(launch)
        }
    }
    private fun restart() {
        if (!listening) android.os.Handler(mainLooper).postDelayed({ if (recognizer != null) beginListening() }, 1200)
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "JARVIS Wake Listener", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onDestroy() { recognizer?.cancel(); recognizer?.destroy(); recognizer = null; super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
