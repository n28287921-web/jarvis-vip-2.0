import express from 'express';

const app = express();
app.use(express.json({ limit: '1mb' }));

// Gemini API key stays on this server. Never put it in the Android APK.
app.post('/chat', async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: 'GEMINI_API_KEY is not configured on the server.' });

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const contents = messages
      .filter(m => m && ['user', 'assistant', 'model'].includes(m.role) && typeof m.content === 'string')
      .slice(-30)
      .map(m => ({
        role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.content.slice(0, 12000) }]
      }));

    if (!contents.length || contents[contents.length - 1].role !== 'user') {
      return res.status(400).json({ error: 'A user message is required.' });
    }

    const memory = typeof req.body?.memory === 'string' ? req.body.memory.slice(0, 4000) : '';
    const systemText = 'You are JARVIS VIP 2.0, a concise and helpful bilingual Hindi and English personal assistant. Reply in the language used by the user. Never claim to have performed phone actions unless Android confirms the action.' +
      (memory ? `\n\nUser-approved saved memory (use only when relevant): ${memory}` : '');
    const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemText }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({ error: data?.error?.message || 'Gemini request failed.' });
    }
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!text) return res.status(502).json({ error: 'Gemini returned an empty response.' });
    return res.json({ reply: text, model });
  } catch (error) {
    console.error('Gemini backend error:', error?.message || error);
    return res.status(500).json({ error: 'Backend request failed.' });
  }
});

app.get('/health', (_, res) => res.json({ ok: true, service: 'JARVIS VIP 2.0', provider: 'Google Gemini' }));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JARVIS Gemini backend listening on ${port}`));
